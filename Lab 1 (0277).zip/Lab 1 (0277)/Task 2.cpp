//#include <iostream>
//#include <fstream>
//#include <sstream>
//#include <string>
//using namespace std;
//
//struct Student
//{
//    string registrationNumber;
//    string firstName;
//    string lastName;
//    string program;
//    double cgpa;
//    string contactNumber;
//};
//
//int main() 
//{
//    ifstream inFile("StudentInfo.csv");
//
//    if (!inFile)
//    {
//        cout << "Error opening file!" << endl;
//        return 1;
//    }
//
//    string line;
//    
//    getline(inFile, line);
//
//    cout << "Students with CGPA >= 3.5:" << endl;
//
//   
//    while (getline(inFile, line)) 
//    {
//        stringstream ss(line);
//        Student student;
//
//       
//        getline(ss, student.registrationNumber, ',');
//        getline(ss, student.firstName, ',');
//        getline(ss, student.lastName, ',');
//        getline(ss, student.program, ',');
//        ss >> student.cgpa;
//        ss.ignore();  
//        getline(ss, student.contactNumber, ',');
//
//       
//        if (student.cgpa >= 3.5)
//        {
//            cout << student.firstName << " " << student.lastName << " (CGPA: " << student.cgpa << ")" << endl;
//        }
//    }
//
//    inFile.close();
//
//    return 0;
//}

//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//struct Department
//{
//    int deptID;
//    string deptName;
//};
//
//struct Employee {
//    string empID;
//    string empName;
//    string empJoiningDate;
//    int deptID;
//    string contact;
//    double salary;
//    string maritalStatus;
//};
//
//void loadDepartments(Department departments[], int& deptCount)
//{
//    ifstream deptFile("department.csv");
//    if (!deptFile) 
//    {
//        cout << "Error opening department file!" << endl;
//        return;
//    }
//
//    string line;
//    
//    getline(deptFile, line);
//
//    
//    deptCount = 0;
//    while (getline(deptFile, line)) 
//    {
//        Department dept;
//        size_t commaPos = line.find(',');
//        dept.deptID = stoi(line.substr(0, commaPos));
//        dept.deptName = line.substr(commaPos + 1);
//
//        departments[deptCount++] = dept;
//    }
//
//    deptFile.close();
//}
//
//
//string getDepartmentName(int deptID, Department departments[], int deptCount)
//{
//    for (int i = 0; i < deptCount; i++) 
//    {
//        if (departments[i].deptID == deptID)
//        {
//            return departments[i].deptName;
//        }
//    }
//    return "";
//}
//
//
//void displayResearchEmployees(Department departments[], int deptCount) 
//{
//    ifstream empFile("employee.csv");
//    if (!empFile) {
//        cout << "Error opening employee file!" << endl;
//        return;
//    }
//
//    string line;
//
//    getline(empFile, line);
//
//    
//    while (getline(empFile, line)) 
//    {
//        Employee emp;
//
//        
//        size_t commaPos = line.find(',');
//        emp.empID = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empName = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empJoiningDate = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.deptID = stoi(line.substr(0, commaPos));
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.contact = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.salary = stod(line.substr(0, commaPos));
//        line = line.substr(commaPos + 1);
//
//        emp.maritalStatus = line;
//
//        
//        if (getDepartmentName(emp.deptID, departments, deptCount) == "Research")
//        {
//            cout << "Employee ID: " << emp.empID
//                << ", Name: " << emp.empName
//                << ", Joining Date: " << emp.empJoiningDate
//                << ", Contact: " << emp.contact
//                << ", Salary: " << emp.salary
//                << ", Marital Status: " << emp.maritalStatus
//                << endl;
//        }
//    }
//
//    empFile.close();
//}
//
//int main() 
//{
//   
//    Department departments[10];  
//    int deptCount = 0;
//
//    loadDepartments(departments, deptCount);
//
//    
//    cout << "Employees working in the Research department:" << endl;
//    displayResearchEmployees(departments, deptCount);
//
//    return 0;
//}

//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//struct Employee 
//{
//    string empID;
//    string empName;
//    string empJoiningDate;
//    string contact;
//    double salary;
//    string maritalStatus;
//};
//
//void displayHighEarningEmployees() 
//{
//    ifstream empFile("employee.csv");
//    if (!empFile) 
//    {
//        cout << "Error opening employee file!" << endl;
//        return;
//    }
//
//    string line;
//    getline(empFile, line);
//
//    while (getline(empFile, line))
//    {
//        Employee emp;
//
//        size_t commaPos = line.find(',');
//        emp.empID = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empName = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empJoiningDate = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.contact = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.salary = stod(line.substr(0, commaPos));
//        line = line.substr(commaPos + 1);
//
//        emp.maritalStatus = line;
//
//        double annualSalary = emp.salary * 12;
//
//        if (annualSalary >= 1500000) 
//        {
//            cout << "Employee Name: " << emp.empName
//                << ", Monthly Salary: " << emp.salary
//                << ", Annual Salary: " << annualSalary
//                << endl;
//        }
//    }
//
//    empFile.close();
//}
//
//int main() 
//{
//    cout << "Employees with an annual salary of 1,500,000 or greater:" << endl;
//    displayHighEarningEmployees();
//
//    return 0;
//}

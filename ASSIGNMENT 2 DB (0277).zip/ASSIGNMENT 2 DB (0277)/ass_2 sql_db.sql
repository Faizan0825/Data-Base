create database l1f23bscs0277;

-- 1. Create STAFFMEMBER table
CREATE TABLE STAFFMEMBER(
 Fname VARCHAR(130) NOT NULL,
 Lname VARCHAR(130) NOT NULL,
 User_no INT NOT NULL,
 PRIMARY KEY(User_no)
);

-- 2. Create PROJECT table
CREATE TABLE PROJECT(
 P_num INT NOT NULL,
 PRIMARY KEY(P_num),
 P_name VARCHAR(100) NOT NULL,
 P_level INT NOT NULL,
 keywords VARCHAR(100) NOT NULL,
 P_description VARCHAR(100) NOT NULL
);

-- 3. Create EXAM table
CREATE TABLE EXAM (
 Stu_user_no INT NOT NULL,
 Exam_no INT NOT NULL,
 PRIMARY KEY(Stu_user_no, Exam_no),
 E_time TIME DEFAULT '12:00:00',
 E_day VARCHAR(50) NOT NULL,
 Room_no INT
);

-- 4. Now create STUDENT_INFORMATION table (after all references exist)
CREATE TABLE STUDENT_INFORMATION(
 Fname VARCHAR(130) NOT NULL,
 Lname VARCHAR(130) NOT NULL,
 User_num INT,
 PRIMARY KEY(User_num),
 Proj_no INT NULL,
 Super_no INT NULL,
 Assessor1 INT,
 Assessor2 INT,
 CONSTRAINT fk1 FOREIGN KEY(Proj_no) REFERENCES PROJECT(P_num),
 CONSTRAINT fk2 FOREIGN KEY(Super_no) REFERENCES STAFFMEMBER(User_no),
 CONSTRAINT fk3 FOREIGN KEY(User_num) REFERENCES EXAM(Stu_user_no)

);
desc STUDENT_INFORMATION;


insert into STAFFMEMBER(Fname, Lname, User_no) values('Faizan','Akbar',40);
insert into STAFFMEMBER(Fname, Lname, User_no) values('Salman','khan',50);
insert into STAFFMEMBER(Fname, Lname, User_no) values('Akbar','Ramzan',60);
insert into STAFFMEMBER(Fname, Lname, User_no) values('Numan','Akbar',10);
insert into STAFFMEMBER(Fname, Lname, User_no) values('Bilal','Mustafa',20);
select * from STAFFMEMBER;
desc STAFFMEMBER;

insert into STUDENT_INFORMATION (Fname, Lname, User_num, Proj_no, Super_no, Assessor1, Assessor2)
values ('Zainab', 'Faizan', 5, 1, 10, 60, 210);
insert into STUDENT_INFORMATION (Fname, Lname, User_num, Proj_no, Super_no, Assessor1, Assessor2)
values ('Naeem', 'Khan', 4, 2, 20, 50, 90);
insert into STUDENT_INFORMATION (Fname, Lname, User_num, Proj_no, Super_no, Assessor1, Assessor2)
values ('Faraz', 'Butt', 3, 3, 30, 40, 70);
insert into STUDENT_INFORMATION (Fname, Lname, User_num, Proj_no, Super_no, Assessor1, Assessor2)
values ('Zaviar', 'Ali', 2, 4, 40, 30, 30);
insert into STUDENT_INFORMATION (Fname, Lname, User_num, Proj_no, Super_no, Assessor1, Assessor2)
values ('Zeeshan', 'Akbar', 1, 5, 50, 10, 50);
select * from STUDENT_INFORMATION;

alter table STUDENT_INFORMATION drop foreign key fk1;
alter table STUDENT_INFORMATION add constraint fk1 foreign key (Proj_no) references PROJECT(P_num) on update cascade;




insert into PROJECT (P_num, P_name, P_level, keywords, P_description) 
values (1, 'EcoTrack', 3, 'Environment,Tracker', 'An app to track personal carbon footprint');
insert into PROJECT (P_num, P_name, P_level, keywords, P_description) 
values (2, 'FitMeal', 2, 'Nutrition,Fitness', 'A mobile app for planning healthy meals and workouts');
insert into PROJECT (P_num, P_name, P_level, keywords, P_description) 
values (3, 'EduQuest', 4, 'Education,Game', 'An educational game for high school students');
insert into PROJECT (P_num, P_name, P_level, keywords, P_description) 
values (4, 'SafeRoute', 3, 'Navigation,Safety', 'A GPS app that suggests safe routes for travel');
insert into PROJECT (P_num, P_name, P_level, keywords, P_description) 
values (5, 'CollabWrite', 2, 'Writing,Teamwork', 'A platform for teams to co-author documents in real-time');
select * from PROJECT;
desc PROJECT;

alter table EXAM modify E_day varchar(50) not null;
insert into EXAM (Stu_user_no, Exam_no, E_time, E_day, Room_no) values(1, 5, '12:00:00', 'Friday', 10);
insert into EXAM(Stu_user_no, Exam_no, E_time, E_day, Room_no) values(2, 4, '11:00:00', 'Thursday', 11);
insert into EXAM(Stu_user_no, Exam_no, E_day, Room_no) values(3, 3, 'Wednesday', 12);
insert into EXAM(Stu_user_no, Exam_no, E_time, E_day, Room_no) values(4, 2, '10:00:00', 'Tuesday', 12);
insert into EXAM(Stu_user_no, Exam_no, E_time, E_day, Room_no) values(5, 1, '09:00:00', 'Friday', 13);
select * from EXAM;
desc EXAM;



update EXAM set Room_no = 3
 where stu_user_no = 5;  
select * from EXAM
 where stu_user_no = 5;

update PROJECT set P_num = 15 
where P_num = 2;
select * from PROJECT;
select * from STUDENT_INFORMATION;
DESC PROJECT;

delete from STUDENT_INFORMATION
 where Proj_no = 10;
select * from STUDENT_INFORMATION;


update PROJECT
 set keywords = 'Fit Meal' 
 where P_num = 5 and keywords = 'Nutri,Fit';
select * from PROJECT;

update PROJECT
 set P_level = 7 
 where P_num = 5 and P_level = 4 and keywords = 'Navigation,Safety';
select * from PROJECT where P_num = 5;

select E_time, E_day
 from EXAM
 where stu_user_no = 1010 and Room_no = 5;

select P_name 
from PROJECT
 order by P_name;


update STAFFMEMBER
 set Fname = 'Faizan', Lname = 'Akbar' 
 where Fname = 'Shazaib' and Lname = 'Asif' and User_no = 10;
select * from STAFFMEMBER;

select Fname, Lname
 from STAFFMEMBER
 where Fname like 'A%A' and Lname like '%A%';

select Fname, Lname
 from STUDENT_INFORMATION
 where Super_no is null;

select stu_user_no
 from EXAM
 where Room_no between 5 and 9;

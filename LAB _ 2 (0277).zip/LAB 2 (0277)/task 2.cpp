#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

void search(const string& filename, const string& reg_no)
{
    ifstream file(filename);

    if (file.is_open())
    {
        string line;
        bool found = false;

        while (getline(file, line))
        {
            stringstream s(line);
            string reg_num, name, department, contact;
            float gpa;

            getline(s, reg_num, ',');
            getline(s, name, ',');
            getline(s, department, ',');
            s >> gpa;
            s.ignore();
            getline(s, contact, ',');

            if (reg_num == reg_no)
            {
                cout << "Student Found!" << endl;
                cout << "Registration Number: " << reg_num << " Name: " << name << endl;
                cout << "Department: " << department << " GPA: " << gpa << endl;
                cout << "Contact Number: " << contact << endl;
                found = true;
                break;
            }
        }

        if (!found)
        {
            cout << "No student found with Registration Number: " << reg_no << endl;
        }

        file.close();
    }
    else
    {
        cout << "File could not be opened!" << endl;
    }
}

void add(const string& filename)
{
    ofstream file(filename, ios::app);

    if (file.is_open())
    {
        string reg_num, name, department, contact;
        float gpa;

        cout << "Enter Registration Number: ";
        cin >> reg_num;
        cin.ignore();

        cout << "Enter Name: ";
        getline(cin, name);

        cout << "Enter Department: ";
        getline(cin, department);

        cout << "Enter GPA: ";
        cin >> gpa;
        cin.ignore();

        cout << "Enter Contact Number: ";
        getline(cin, contact);

        if (file.tellp() == 0)
        {
            file << "RegNo,Name,Department,GPA,Contact\n";
        }

        file << reg_num << "," << name << "," << department << "," << gpa << "," << contact << "\n";

        cout << "New student added successfully!" << endl;

        file.close();
    }

    else
    {
        cout << "File could not be opened!" << endl;
    }
}

void update_GPA(const string& registration_number, const string& updated_CGPA, const string& file_name = "data.csv")
{
    ifstream input_file(file_name);
    if (!input_file.is_open())
    {
        cout << "Error opening the file!" << endl;
        return;
    }

    stringstream file_contents;
    string line;
    bool updated = false;

    while (getline(input_file, line))
    {
        stringstream ss(line);
        string reg_num, name, department, contact, cgpa;

        getline(ss, reg_num, ',');
        getline(ss, name, ',');
        getline(ss, department, ',');
        getline(ss, cgpa, ',');
        getline(ss, contact, ',');

        if (reg_num == registration_number)
        {
            
            line = reg_num + "," + name + "," + department + "," + updated_CGPA + "," + contact;
            updated = true;
        }

        file_contents << line << endl;
    }

    input_file.close();

    if (updated)
    {
        ofstream original_file(file_name, ios::out | ios::trunc);
        if (!original_file.is_open())
        {
            cout << "Error opening original file for overwriting!" << endl;
            return;
        }

        original_file << file_contents.str();
        original_file.close();

        cout << "GPA updated : " << registration_number << endl;
    }
}

void deleteStud(const string& filename, const string& reg_no) 
{
    ifstream input_file(filename);
    if (!input_file.is_open()) {
        cout << "Error opening the file!" << endl;
        return;
    }

    stringstream file_contents;
    string line;
    bool deleted = false;

    while (getline(input_file, line)) 
    {
        stringstream ss(line);
        string reg_num;

        getline(ss, reg_num, ',');

        if (reg_num != reg_no) 
        {
            file_contents << line << endl;
        }
        else {
            deleted = true;
        }
    }

    input_file.close();

    if (deleted) 
    {
        ofstream original_file(filename, ios::out | ios::trunc);
        if (!original_file.is_open()) {
            cout << "Error opening original file for overwriting!" << endl;
            return;
        }

        original_file << file_contents.str();
        original_file.close();

        cout << "Student with Registration Number " << reg_no << " has been deleted." << endl;
    }
    else {
        cout << "No student found with Registration Number " << reg_no << endl;
    }
}

int main()
{
    string filename = "data.csv";
    string reg_no;
    int choice;

    cout << "1. Search for a student" << endl;
    cout << "2. Add a new student" << endl;
    cout << "3. Update CGPA" << endl;
    cout << "4. Delete a student" << endl;
    cout << "Enter your choice: ";

    cin >> choice;

    if (choice == 1)
    {
        cout << "Enter Registration Number to search: ";
        cin >> reg_no;
        search(filename, reg_no);
    }
    else if (choice == 2)
    {
        add(filename);
    }
    else if (choice == 3)
    {
        cout << "Enter Registration Number to update CGPA: ";
        cin >> reg_no;
        string updated_CGPA;
        cout << "Enter updated CGPA: ";
        cin >> updated_CGPA;
        update_GPA(reg_no, updated_CGPA, filename);
    }
    else if (choice == 4)
    {
        cout << "Enter Registration Number to delete: ";
        cin >> reg_no;
        deleteStud(filename, reg_no);
    }
    else
    {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}
